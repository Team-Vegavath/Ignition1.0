from flask import Flask, jsonify
from flask_cors import CORS
import serial, threading, json, math, time

app = Flask(name)
CORS(app)  # ✅ Allow access from React / Android / Web

# ---------------- CONFIG ---------------- #
PORT = "/dev/ttyACM0"   # Change if different (e.g. COM3 on Windows)
BAUD = 9600
latest_data = {}
ser = None

# ---------------- SERIAL READER ---------------- #
def connect_serial():
    """Try to connect to Arduino until successful"""
    global ser
    while True:
        try:
            ser = serial.Serial(PORT, BAUD, timeout=1)
            print(f"✅ Connected to Arduino on {PORT}")
            return
        except Exception as e:
            print("⚠ Waiting for Arduino connection...")
            time.sleep(1)
def read_serial():
    """Continuously read and parse JSON data from Arduino"""
    global latest_data, ser
    connect_serial()  # connect first
    while True:
        try:
            if not ser or not ser.is_open:
                connect_serial()
            line = ser.readline().decode(errors="ignore").strip()
            if line.startswith("{") and line.endswith("}"):
                try:
                    data = json.loads(line)
                    latest_data = process_data(data)
                except json.JSONDecodeError:
                    continue
        except Exception as e:
            print("⚠ Serial read error:", e)
            time.sleep(0.5)
            connect_serial()
# ---------------- DATA PROCESSOR ---------------- #
def process_data(d):
    """Calculate posture, smoothness, crash detection, and ride mode"""
    # Basic tilt (posture)
    tilt = d.get("tilt", 0)
    if tilt > 10:
        posture = "Leaning Forward"
    elif tilt < -10:
        posture = "Leaning Backward"
    else:
        posture = "Upright"

    # Determine speed (prefer GPS if available)
    gps_spd = d.get("gps_spd", 0.0)
    mpu_spd = d.get("mpu_spd", 0.0)
    spd = gps_spd if gps_spd > 0.2 else mpu_spd  # switch automatically

    # Determine ride mode
    if spd < 1:
        ride_mode = "Idle"
    elif spd < 5:
        ride_mode = "Walking"
    elif spd < 25:
        ride_mode = "Scooter"
    else:
        ride_mode = "Bike"
from flask import Flask, jsonify
from flask_cors import CORS
import serial, threading, json, math, time

app = Flask(name)
CORS(app)  # ✅ Allow access from React / Android / Web

# ---------------- CONFIG ---------------- #
PORT = "/dev/ttyACM0"   # Change if different (e.g. COM3 on Windows)
BAUD = 9600
latest_data = {}
ser = None

# ---------------- SERIAL READER ---------------- #
def connect_serial():
    """Try to connect to Arduino until successful"""
    global ser
    while True:
        try:
            ser = serial.Serial(PORT, BAUD, timeout=1)
            print(f"✅ Connected to Arduino on {PORT}")
            return
        except Exception as e:
            print("⚠ Waiting for Arduino connection...")
            time.sleep(1)
def read_serial():
    """Continuously read and parse JSON data from Arduino"""
    global latest_data, ser
    connect_serial()  # connect first
    while True:
        try:
            if not ser or not ser.is_open:
                connect_serial()
            line = ser.readline().decode(errors="ignore").strip()
            if line.startswith("{") and line.endswith("}"):
                try:
                    data = json.loads(line)
                    latest_data = process_data(data)
                except json.JSONDecodeError:
                    continue
        except Exception as e:
            print("⚠ Serial read error:", e)
            time.sleep(0.5)
            connect_serial()
# ---------------- DATA PROCESSOR ---------------- #
def process_data(d):
    """Calculate posture, smoothness, crash detection, and ride mode"""
    # Basic tilt (posture)
    tilt = d.get("tilt", 0)
    if tilt > 10:
        posture = "Leaning Forward"
    elif tilt < -10:
        posture = "Leaning Backward"
    else:
        posture = "Upright"

    # Determine speed (prefer GPS if available)
    gps_spd = d.get("gps_spd", 0.0)
    mpu_spd = d.get("mpu_spd", 0.0)
    spd = gps_spd if gps_spd > 0.2 else mpu_spd  # switch automatically

    # Determine ride mode
    if spd < 1:
        ride_mode = "Idle"
    elif spd < 5:
        ride_mode = "Walking"
    elif spd < 25:
        ride_mode = "Scooter"
    else:
        ride_mode = "Bike"
    # Crash detection
    ax, ay, az = d.get("ax", 0), d.get("ay", 0), d.get("az", 0)
    g_total = math.sqrt(ax*2 + ay2 + az*2)
    crash = "⚠ Crash Detected!" if g_total > 20 else "Normal"

    # Smoothness
    gx, gy, gz = d.get("gx", 0), d.get("gy", 0), d.get("gz", 0)
    gyro_mag = math.sqrt(gx*2 + gy2 + gz*2)
    smoothness = round(max(0, min(100, 100 - gyro_mag * 10)), 1)

    # GPS info
    lat = d.get("lat")
    lon = d.get("lon")
    sat = d.get("sat", 0)

    # ✅ Merge computed data
    d.update({
        "posture": posture,
        "ride_mode": ride_mode,
        "crash": crash,
        "smoothness": smoothness,
        "spd": spd,
        "lat": lat,
        "lon": lon,
        "sat": sat
    })
    return d

# ---------------- API ROUTE ---------------- #
@app.route("/data")
def data():
    """Return latest telemetry JSON"""
    if latest_data:
        return jsonify(latest_data)
    else:
        return jsonify({"status": "waiting_for_data"})

# ---------------- MAIN ---------------- #
if name == "main":
    print("🚀 Starting RideAssist Telemetry Server...")
    threading.Thread(target=read_serial, daemon=True).start()
    app.run(host="0.0.0.0", port=5000, debug=False)